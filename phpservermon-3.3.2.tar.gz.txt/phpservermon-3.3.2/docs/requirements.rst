.. _requirements:

Requirements
============

* Web server
* MySQL database
* PHP 5.5.9+
* PHP cURL package
* PHP PDO mysql driver